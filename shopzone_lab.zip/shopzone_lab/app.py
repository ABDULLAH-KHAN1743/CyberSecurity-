from flask import Flask, request, render_template, redirect, session, url_for, g
import sqlite3, os
app=Flask(__name__); app.secret_key='lab-only-secret-key'
DB=os.path.join(os.path.dirname(__file__),'shopzone.db')
def get_db():
    if 'db' not in g: g.db=sqlite3.connect(DB); g.db.row_factory=sqlite3.Row
    return g.db
@app.teardown_appcontext
def close_db(e=None):
    db=g.pop('db',None)
    if db: db.close()
@app.route('/')
def home(): return render_template('index.html')
@app.route('/products')
def products():
    q=request.args.get('q',''); db=get_db()
    if q: rows=db.execute("SELECT * FROM products WHERE name LIKE '%"+q+"%' OR description LIKE '%"+q+"%'").fetchall()
    else: rows=db.execute('SELECT * FROM products').fetchall()
    return render_template('products.html',products=rows,q=q)
@app.route('/product/<int:product_id>')
def product(product_id):
    row=get_db().execute('SELECT * FROM products WHERE id=?',(product_id,)).fetchone()
    return render_template('product.html',product=row) if row else ('Product not found',404)
@app.route('/login',methods=['GET','POST'])
def login():
    msg=''
    if request.method=='POST':
        u=request.form.get('username',''); p=request.form.get('password','')
        row=get_db().execute("SELECT * FROM users WHERE username = '"+u+"' AND password = '"+p+"'").fetchone()
        if row: session['user_id']=row['id']; session['username']=row['username']; return redirect(url_for('profile'))
        msg='Invalid username or password.'
    return render_template('login.html',message=msg)
@app.route('/profile')
def profile():
    if 'user_id' not in session: return redirect(url_for('login'))
    row=get_db().execute('SELECT id,username,email FROM users WHERE id=?',(session['user_id'],)).fetchone()
    return render_template('profile.html',user=row)
@app.route('/logout')
def logout(): session.clear(); return redirect(url_for('home'))
def init_db():
    db=sqlite3.connect(DB); c=db.cursor(); c.executescript('''
    CREATE TABLE users(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT UNIQUE NOT NULL,password TEXT NOT NULL,email TEXT NOT NULL);
    CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,description TEXT NOT NULL,price REAL NOT NULL);
    INSERT INTO users(username,password,email) VALUES ('alex','Sunset2026!','alex@shopzone.local'),('mira','BlueSky#82','mira@shopzone.local'),('admin','AdminLab!2026','admin@shopzone.local');
    INSERT INTO products(name,description,price) VALUES ('Wireless Headphones','Comfortable over-ear headphones.',59.99),('Mechanical Keyboard','Compact mechanical keyboard.',79.99),('USB-C Hub','Multi-port USB-C hub.',34.50),('Smart Lamp','Adjustable desk lamp.',28.00);
    '''); db.commit(); db.close()
if __name__=='__main__':
    if not os.path.exists(DB): init_db()
    app.run(host='0.0.0.0',port=5000,debug=False)
