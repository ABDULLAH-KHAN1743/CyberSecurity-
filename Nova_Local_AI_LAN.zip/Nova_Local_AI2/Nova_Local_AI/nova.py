#!/usr/bin/env python3
import os,sys,json,re,subprocess,base64,hashlib,random,struct,zlib,math,urllib.request,urllib.parse
from pathlib import Path
from datetime import datetime
from html import unescape
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from urllib.parse import urlparse

ROOT=Path(__file__).parent.resolve(); STATIC=ROOT/'static'; MEM=ROOT/'memory'; WORK=ROOT/'workspace'
for p in (STATIC,MEM,WORK): p.mkdir(exist_ok=True)
MEMORY=MEM/'memory.json'; BRAIN=MEM/'brain.json'
def load(p,d):
    try:return json.loads(p.read_text(encoding='utf8'))
    except:return d
memory=load(MEMORY,{'facts':[],'chat':[],'sources':[]}); brain=load(BRAIN,{'learned':[],'preferences':{},'skills':['python','javascript','bash','linux','cybersecurity'],'summary':'','version':1})
def save(p,x): p.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf8')
def remember(s,kind='fact'):
    if s.strip():
        memory['facts'].append({'time':datetime.now().isoformat(timespec='seconds'),'type':kind,'text':s.strip()}); memory['facts']=memory['facts'][-500:]; save(MEMORY,memory)
def learn(s):
    pats=[(r'remember(?: that)? (.+)','fact'),(r'মনে রাখ(?:বে|ো)?(?: যে)? (.+)','fact'),(r'i prefer (.+)','preference'),(r'আমি (.+) পছন্দ করি','preference')]
    for p,k in pats:
        m=re.search(p,s,re.I)
        if m:
            v=m.group(1).strip(); brain['learned'].append({'time':datetime.now().isoformat(timespec='seconds'),'type':k,'value':v}); brain['learned']=brain['learned'][-500:]
            if k=='preference': brain['preferences']['user_preference']=v
            save(BRAIN,brain); remember(v,k); return True
    return False
def log_chat(role,text):
    memory['chat'].append({'time':datetime.now().isoformat(timespec='seconds'),'role':role,'text':text[:12000]}); memory['chat']=memory['chat'][-500:]; save(MEMORY,memory)
def brain_update():
    # Conversation-derived long-term memory: compact, persistent, user-controlled notes.
    topics=[]
    for x in memory['chat'][-100:]:
        t=x['text'].lower()
        for key in ('python','linux','cybersecurity','burp','idor','bola','sql injection','javascript','bash','automation','bangla','english'):
            if key in t and key not in topics: topics.append(key)
    brain['skills']=sorted(set(brain.get('skills',[])+topics))
    brain['summary']=('User conversation topics: '+', '.join(brain['skills'])) if brain['skills'] else ''
    brain['version']=int(brain.get('version',1))+1
    save(BRAIN,brain)

TEMPLATES={
'python port checker':'''import socket, sys
host=sys.argv[1] if len(sys.argv)>1 else "127.0.0.1"
for port in range(1,101):
    with socket.socket() as s:
        s.settimeout(.15)
        if s.connect_ex((host,port))==0: print(f"{host}:{port} OPEN")''',
'python http headers':'''from urllib.request import Request,urlopen
import sys
url=sys.argv[1] if len(sys.argv)>1 else "http://127.0.0.1:5000/"
with urlopen(Request(url),timeout=5) as r:
 print("HTTP",r.status)
 for k,v in r.headers.items(): print(f"{k}: {v}")''',
'python hash':'''import hashlib,sys
from pathlib import Path
p=Path(sys.argv[1]); h=hashlib.sha256()
with p.open('rb') as f:
 for c in iter(lambda:f.read(1048576),b''): h.update(c)
print(h.hexdigest())''',
'python todo':'''todos=[]
def add(text):
 text=text.strip()
 if text: todos.append({'text':text,'done':False})
def show():
 for i,t in enumerate(todos,1): print(f"{i}. [{'x' if t['done'] else ' '}] {t['text']}")
add('Learn Python'); add('Practice Linux'); show()''',
'javascript counter':'''let count=0; for(let i=0;i<5;i++){count++; console.log('count =',count)}''',
'bash backup':'''#!/usr/bin/env bash
set -euo pipefail
SRC="${1:-./workspace}"; DEST="${2:-./backup-$(date +%Y%m%d-%H%M%S)}"
mkdir -p "$DEST"; cp -a "$SRC"/. "$DEST"/; echo "Backup: $DEST"''',
'bash log':'''#!/usr/bin/env bash
set -euo pipefail
FILE="${1:?LOGFILE required}"; PATTERN="${2:-error}"; grep -niE "$PATTERN" "$FILE" || true'''
}
def codegen(q):
 s=q.lower()
 if 'port' in s and ('check' in s or 'scan' in s): k='python port checker'
 elif 'http' in s and 'header' in s:k='python http headers'
 elif 'hash' in s and 'file' in s:k='python hash'
 elif 'backup' in s:k='bash backup'
 elif 'grep' in s or 'log' in s:k='bash log'
 elif 'javascript' in s or re.search(r'\bjs\b',s):k='javascript counter'
 else:k='python todo'
 lang='python' if k.startswith('python') else ('javascript' if k.startswith('javascript') else 'bash')
 return {'language':lang,'code':TEMPLATES[k],'template':k}

def fetch_url(url,timeout=12):
    if not re.match(r'^https?://',url,re.I): url='https://'+url
    req=urllib.request.Request(url,headers={'User-Agent':'Nova-Local-AI/2.0'})
    with urllib.request.urlopen(req,timeout=timeout) as r:
        data=r.read(600000); ctype=r.headers.get('content-type','')
        text=data.decode('utf-8','replace')
        text=re.sub(r'<script[\s\S]*?</script>|<style[\s\S]*?</style>',' ',text,flags=re.I)
        text=re.sub(r'<[^>]+>',' ',text); text=unescape(re.sub(r'\s+',' ',text)).strip()
        return {'url':r.geturl(),'status':r.status,'content_type':ctype,'text':text[:30000]}

def web_search(q,limit=6):
    # No search API: use DuckDuckGo's public HTML search page from the local machine.
    u='https://html.duckduckgo.com/html/?q='+urllib.parse.quote(q)
    req=urllib.request.Request(u,headers={'User-Agent':'Mozilla/5.0 Nova-Local-AI'})
    with urllib.request.urlopen(req,timeout=12) as r: html=r.read(700000).decode('utf-8','replace')
    out=[]
    for m in re.finditer(r'<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>(.*?)</a>',html,re.I|re.S):
        href=unescape(m.group(1)); title=re.sub(r'<[^>]+>','',unescape(m.group(2))).strip()
        if href.startswith('//'): href='https:'+href
        out.append({'title':title,'url':href})
        if len(out)>=limit: break
    return out

def research(q):
    try:
        results=web_search(q)
        memory['sources']=[{'time':datetime.now().isoformat(timespec='seconds'),'query':q,'results':results}]+memory['sources'][:49]; save(MEMORY,memory)
        snippets=[]
        for x in results[:4]:
            try:
                d=fetch_url(x['url'],8); snippets.append({'title':x['title'],'url':d['url'],'text':d['text'][:5000]})
            except: snippets.append({'title':x['title'],'url':x['url'],'text':''})
        return {'query':q,'results':snippets}
    except Exception as e:return {'query':q,'results':[],'error':str(e)}

def local_model(prompt,context=''):
    cmd=os.getenv('NOVA_LLAMA_CMD'); model=os.getenv('NOVA_MODEL')
    if not cmd or not model or not Path(cmd).exists() or not Path(model).exists(): return None
    facts='\n'.join('- '+x['text'] for x in memory['facts'][-20:])
    history='\n'.join(x['role']+': '+x['text'] for x in memory['chat'][-12:])
    full=f'''You are Nova, a friendly local bilingual AI assistant. Reply in Bangla or English matching the user. Use the supplied web research when present and cite source URLs in plain text. Never claim you browsed unless research is supplied. You can write code and authorized cybersecurity lab/CTF scripts; do not help attack real systems without authorization. Be practical and conversational.\nLong-term memory:\n{facts}\nRecent conversation:\n{history}\nWeb research:\n{context}\nUser:\n{prompt}\nNova:'''
    try:
        p=subprocess.run([cmd,'-m',model,'-p',full,'-n','1200','--temp','0.7'],capture_output=True,text=True,timeout=120,cwd=WORK)
        return p.stdout.strip() if p.returncode==0 and p.stdout.strip() else None
    except:return None

def chat(msg,use_web=False):
    learn(msg); log_chat('user',msg); brain_update()
    ctx=''
    if use_web: 
        r=research(msg); ctx=json.dumps(r,ensure_ascii=False)[:24000]
    m=local_model(msg,ctx)
    if m:r=m; mode='online-research+local-llm' if use_web else 'local-llm'
    else:
        t=msg.strip(); l=t.lower()
        if use_web:
            r='Web research complete.\n\n'+('\n'.join(f"• {x['title']} — {x['url']}" for x in json.loads(ctx).get('results',[])) if json.loads(ctx).get('results') else 'কোনো result পাওয়া যায়নি।')
            mode='online-research'
        elif re.match(r'^(hi|hello|hey)\b',l): r='হ্যালো! আমি Nova। 😊 Bangla/English-এ কথা বলতে পারি। Coding, Linux, cybersecurity lab, automation, web research এবং voice mode-এ কাজ করতে পারি।'; mode='local-rules'
        elif 'memory' in l or ('মনে' in t and ('কি' in t or 'কী' in t)): r='আমার local memory:\n'+'\n'.join('• '+x['text'] for x in memory['facts'][-15:]) if memory['facts'] else 'এখনও memory খালি।'; mode='local-rules'
        elif 'code' in l or 'কোড' in t or 'script' in l or 'স্ক্রিপ্ট' in t: c=codegen(t); r=f"{c['template']}\n\n```{c['language']}\n{c['code']}\n```"; mode='local-rules'
        elif 'cyber' in l or 'security' in l or 'সাইবার' in t:r='Cybersecurity mode: authorized lab/CTF-এর জন্য Python/Bash utilities, HTTP inspection, hashing, enumeration, automation ও exploit-development concepts-এ সাহায্য করতে পারি.'; mode='local-rules'
        else:r='বুঝেছি। তুমি চাইলে আমি web research চালিয়ে source দেখে উত্তর দিতে পারি, অথবা local mode-এ দ্রুত উত্তর দিতে পারি।'; mode='local-rules'
    log_chat('assistant',r); brain_update(); return {'reply':r,'mode':mode,'web_used':use_web}

def run_code(lang,code):
    if len(code)>100000:return {'ok':False,'error':'Code too large'}
    if lang in ('python','py'): cmd=[sys.executable,'-I','-c',code]
    elif lang in ('javascript','js'):cmd=[os.getenv('NOVA_NODE','node'),'-e',code]
    else:return {'ok':False,'error':'Use Python or JavaScript'}
    try:
        p=subprocess.run(cmd,cwd=WORK,capture_output=True,text=True,timeout=10)
        return {'ok':p.returncode==0,'returncode':p.returncode,'stdout':p.stdout[-12000:],'stderr':p.stderr[-12000:]}
    except subprocess.TimeoutExpired:return {'ok':False,'error':'Execution timed out'}
    except Exception as e:return {'ok':False,'error':str(e)}

def chunk(k,d):return struct.pack('>I',len(d))+k+d+struct.pack('>I',zlib.crc32(k+d)&0xffffffff)
def image_png(prompt,style='neon'):
    w=h=384; seed=int(hashlib.sha256((prompt+style).encode()).hexdigest()[:8],16); rnd=random.Random(seed)
    pal={'neon':((20,5,45),(230,40,180)),'ocean':((5,45,80),(15,170,160)),'sunset':((35,35,85),(235,125,80)),'forest':((10,50,25),(90,160,70))}.get(style,((25,30,65),(190,100,120)))
    raw=[]
    for y in range(h):
        row=bytearray([0]); t=y/(h-1)
        for x in range(w):
            wave=math.sin(x*.035+y*.012)*12; c=[int(pal[0][i]*(1-t)+pal[1][i]*t+wave) for i in range(3)]
            if rnd.random()<.002:c=[255,240,180]
            row.extend(max(0,min(255,v)) for v in c)
        raw.append(bytes(row))
    return b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',w,h,8,2,0,0,0))+chunk(b'IDAT',zlib.compress(b''.join(raw),9))+chunk(b'IEND',b'')

class H(BaseHTTPRequestHandler):
    def log_message(self,f,*a):pass
    def send(self,status,data,ctype='application/json; charset=utf-8'):
        if isinstance(data,str):data=data.encode()
        self.send_response(status);self.send_header('Content-Type',ctype);self.send_header('Content-Length',str(len(data)));self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(data)
    def body(self):
        n=int(self.headers.get('Content-Length','0')); return json.loads(self.rfile.read(min(n,1048576)) or b'{}')
    def do_GET(self):
        p=urlparse(self.path).path
        if p=='/api/status': return self.send(200,json.dumps({'name':'Nova','internet':True,'local_llm':bool(os.getenv('NOVA_LLAMA_CMD') and os.getenv('NOVA_MODEL')),'python':sys.version.split()[0],'memory':len(memory['facts']),'conversation_turns':len(memory['chat']),'brain_version':brain.get('version',1)}))
        if p=='/api/memory': return self.send(200,json.dumps({'memory':memory,'brain':brain},ensure_ascii=False))
        if p=='/': return self.send(200,(STATIC/'index.html').read_bytes(),'text/html; charset=utf-8')
        if p.startswith('/static/'):
            f=(ROOT/p.lstrip('/')).resolve()
            if not f.exists() or ROOT not in f.parents:return self.send(404,'Not found','text/plain')
            c='text/plain; charset=utf-8' if f.suffix not in ('.css','.js') else ('text/css; charset=utf-8' if f.suffix=='.css' else 'application/javascript; charset=utf-8');return self.send(200,f.read_bytes(),c)
        return self.send(404,'Not found','text/plain')
    def do_POST(self):
        try:
            p=urlparse(self.path).path;b=self.body()
            if p=='/api/chat':return self.send(200,json.dumps(chat(str(b.get('message','')),bool(b.get('web',False))),ensure_ascii=False))
            if p=='/api/research':return self.send(200,json.dumps(research(str(b.get('query',''))),ensure_ascii=False))
            if p=='/api/code':return self.send(200,json.dumps(codegen(str(b.get('request',''))),ensure_ascii=False))
            if p.startswith('/api/run/'):return self.send(200,json.dumps(run_code('python' if p.endswith('python') else 'javascript',str(b.get('code',''))),ensure_ascii=False))
            if p=='/api/memory':remember(str(b.get('text','')),'manual');brain_update();return self.send(200,'{"ok":true}')
            if p=='/api/image':
                x=image_png(str(b.get('prompt','abstract cyberpunk landscape')),str(b.get('style','neon')));return self.send(200,json.dumps({'ok':True,'mime':'image/png','data':base64.b64encode(x).decode()}))
            return self.send(404,'{"error":"Not found"}')
        except Exception as e:return self.send(400,json.dumps({'error':str(e)}))

if __name__=='__main__':
    # Localhost is the safe default. Use `--lan` or NOVA_HOST=0.0.0.0
    # when you want phones/laptops on the same LAN to connect.
    lan='--lan' in sys.argv
    host=os.getenv('NOVA_HOST','0.0.0.0' if lan else '127.0.0.1')
    port=int(os.getenv('NOVA_PORT','8787'))
    server=ThreadingHTTPServer((host,port),H)
    print(f'Nova server listening on {host}:{port}')
    if host in ('0.0.0.0','::'):
        import socket
        ips=[]
        try:
            for x in socket.getaddrinfo(socket.gethostname(),None,socket.AF_INET):
                ip=x[4][0]
                if not ip.startswith('127.') and ip not in ips: ips.append(ip)
        except Exception: pass
        print('LAN access:')
        for ip in ips: print(f'  http://{ip}:{port}')
        print('Make sure your OS firewall allows TCP port',port,'on your private LAN.')
        print('Security: LAN mode exposes local code execution; use only on a trusted network.')
    else:
        print(f'Open: http://127.0.0.1:{port}')
    server.serve_forever()
