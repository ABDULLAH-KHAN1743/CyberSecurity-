const $=x=>document.getElementById(x),chat=$('chat'); let lastReply='';
function msg(t,c){let d=document.createElement('div');d.className='msg '+c;d.textContent=t;chat.appendChild(d);chat.scrollTop=chat.scrollHeight}
async function api(p,b){let r=await fetch(p,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)});return r.json()}
fetch('/api/status').then(r=>r.json()).then(s=>$('status').textContent=`internet ✓ • memory ${s.memory} • turns ${s.conversation_turns} • brain v${s.brain_version} • ${s.local_llm?'local GGUF':'built-in rules'}`);msg('হ্যালো! আমি Nova। 😊 Bangla/English-এ কথা বলো। Internet research on আছে।','b');
$('f').onsubmit=async e=>{e.preventDefault();let q=$('q').value.trim();if(!q)return;$('q').value='';msg(q,'u');let r=await api('/api/chat',{message:q,web:$('web').checked});lastReply=r.reply||r.error;msg(lastReply,'b');if($('speak').dataset.auto==='1')speak(lastReply)};
$('genCode').onclick=async()=>{let r=await api('/api/code',{request:$('q').value||'write a Python script'});$('lang').value=r.language;$('code').value=r.code};
$('run').onclick=async()=>{let p=$('lang').value==='python'?'/api/run/python':'/api/run/javascript';$('out').textContent=JSON.stringify(await api(p,{code:$('code').value}),null,2)};
$('gen').onclick=async()=>{let r=await api('/api/image',{prompt:$('prompt').value||'abstract cyberpunk city',style:$('style').value});if(r.data)$('img').src='data:image/png;base64,'+r.data};
function speak(t){if(!('speechSynthesis' in window))return; speechSynthesis.cancel();let u=new SpeechSynthesisUtterance(t);u.lang=/[\u0980-\u09FF]/.test(t)?'bn-BD':'en-US';u.rate=.95;speechSynthesis.speak(u)}
$('speak').onclick=()=>{if(lastReply)speak(lastReply);$('speak').dataset.auto='1'};
let rec=null;if('SpeechRecognition' in window||'webkitSpeechRecognition' in window){const R=window.SpeechRecognition||window.webkitSpeechRecognition;rec=new R();rec.lang='bn-BD';rec.interimResults=false;rec.onresult=e=>$('q').value=e.results[0][0].transcript;$('mic').onclick=()=>{try{rec.start()}catch{}}}else $('mic').disabled=true;
