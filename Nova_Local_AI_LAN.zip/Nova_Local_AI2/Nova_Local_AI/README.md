# Nova Local + Internet AI

Nova is a local-first personal assistant. It can use the internet for search/fetch when you enable Internet research, while the server, memory and UI remain on your machine.

## Features
- Bangla + English chat
- Internet research without OpenAI/Gemini/Claude API: local HTTP client + DuckDuckGo HTML search
- Persistent conversation history and explicit long-term memory
- Brain profile/version updates from conversation topics and saved preferences
- Optional local GGUF model through llama.cpp (`NOVA_LLAMA_CMD`, `NOVA_MODEL`) for much more natural answers
- Code generation templates + local Python/JavaScript execution
- Cybersecurity learning, automation and authorized lab/CTF scripting
- Browser voice input + speech output using Web Speech APIs
- Offline procedural image generation; optional future local diffusion model can replace it

## Run
Windows:
`py nova.py`

Kali/Linux:
`python3 nova.py`

Open locally: `http://127.0.0.1:8787`

## Use Nova from another device on the same Wi-Fi/LAN
Start Nova in LAN mode:

Windows PowerShell:
`py nova.py --lan`

Kali/Linux:
`python3 nova.py --lan`

Nova will listen on `0.0.0.0:8787` and print the computer's LAN IP, for example `http://192.168.0.101:8787`. On your phone or another laptop connected to the **same Wi-Fi/LAN**, open that address in a browser.

You can also set a custom host/port:
- Windows: `$env:NOVA_HOST='0.0.0.0'; $env:NOVA_PORT='8787'; py nova.py`
- Linux/Kali: `NOVA_HOST=0.0.0.0 NOVA_PORT=8787 python3 nova.py`

Important: `192.168.0.1` is commonly the router address; use the **Nova computer's** LAN address printed by Nova (usually something like `192.168.0.100` or `192.168.1.20`).

If another device cannot connect, allow TCP `8787` through the host computer's firewall and make sure both devices are on the same private network. Do not port-forward Nova directly to the public internet.

## Internet mode
The assistant can search the web and fetch pages directly from your machine. This is not a hosted AI API. Web pages may change or block automated requests, so research results can be incomplete.

## Local model (optional)
Install/build llama.cpp and obtain a GGUF model, then set:
- Windows PowerShell: `$env:NOVA_LLAMA_CMD='C:\path\llama-cli.exe'; $env:NOVA_MODEL='C:\models\model.gguf'`
- Linux/Kali: `export NOVA_LLAMA_CMD=/path/llama-cli; export NOVA_MODEL=/path/model.gguf`

Then start Nova. The local model receives conversation memory and web research context.

## Security
The code runner executes code on the local machine. Do not expose Nova to untrusted networks. Cybersecurity code should be used only on systems you own or are explicitly authorized to test. For exploit-development learning, keep targets inside your own lab/CTF environment.
